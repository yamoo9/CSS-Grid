module.exports = {

  // CSS Grid: IE 브라우저 지원 설정
  grid: true,

  // Vendor Prefix 처리 범위 설정
  browsers: [
    "> 1% in KR",
    "ie >= 10"
  ],

};