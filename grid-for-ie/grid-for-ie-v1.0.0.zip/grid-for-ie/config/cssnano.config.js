module.exports = {
  preset: [

    "default",

    // 기본 설정 덮어쓰기
    {
      // 주석 제거 설정
      discardComments: { removeAll: true }
    }

  ]
};
