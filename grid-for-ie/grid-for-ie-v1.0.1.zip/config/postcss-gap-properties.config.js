module.exports = {
  // 컴파일 과정에서 gap, column-gap, row-gap 속성을 보존할지 유무 설정
  preserve: true
};
